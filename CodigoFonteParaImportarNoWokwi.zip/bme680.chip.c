#include "wokwi-api.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

// BME680 I2C addresses
#define BME680_ADDR_PRIMARY  0x76
#define BME680_ADDR_SECONDARY 0x77

// BME680 Registers (simplified for simulation)
#define BME680_REG_CHIPID     0xD0
#define BME680_REG_RESET      0xE0
#define BME680_REG_CTRL_MEAS 0x74
#define BME680_REG_CONFIG     0x75
#define BME680_REG_DATA       0x1F

typedef struct {
  i2c_dev_t i2c_dev;
  uint8_t reg_addr;
  float temperature;
  float humidity;
  float pressure;
  float gas_res;
  uint32_t temp_attr;
  uint32_t hum_attr;
  uint32_t press_attr;
  uint32_t gas_attr;
  timer_t timer;
} chip_state_t;

// Convert float temperature to Q16 format (BME680 specific)
static int16_t float_to_q16(float value) {
  return (int16_t)(value * 16.0f);
}

// Convert float humidity to unsigned Q16 format
static uint16_t float_to_uh(float value) {
  return (uint16_t)(value * 1024.0f / 100.0f);
}

static void timer_callback(void *user_data) {
  chip_state_t *chip = (chip_state_t*)user_data;
  
  // Update values from attributes
  chip->temperature = attr_read_float(chip->temp_attr);
  chip->humidity = attr_read_float(chip->hum_attr);
  chip->pressure = attr_read_float(chip->press_attr);
  chip->gas_res = attr_read_float(chip->gas_attr);
  
  // printf("Sensor values updated: T=%.1fC, H=%.1f%%, P=%.1fhPa, G=%.0fΩ\n",
  //       chip->temperature, chip->humidity, chip->pressure, chip->gas_res);
}

bool i2c_connect(void *user_data, uint32_t address, bool read) {
  chip_state_t *chip = (chip_state_t*)user_data;
  return (address == BME680_ADDR_PRIMARY) || (address == BME680_ADDR_SECONDARY);
}

uint8_t i2c_read(void *user_data) {
  chip_state_t *chip = (chip_state_t*)user_data;
  
  switch(chip->reg_addr) {
    case BME680_REG_CHIPID:
      return 0x61; // Fixed Chip ID
    
    case BME680_REG_DATA: {
      static uint8_t data[15];
      // Temperature (20-bit)
      int32_t temp = (int32_t)(chip->temperature * 100.0f);
      data[0] = (temp >> 12) & 0xFF;
      data[1] = (temp >> 4) & 0xFF;
      data[2] = (temp & 0xF) << 4;
      
      // Pressure (20-bit)
      int32_t press = (int32_t)(chip->pressure * 100.0f);
      data[3] = (press >> 12) & 0xFF;
      data[4] = (press >> 4) & 0xFF;
      data[5] = (press & 0xF) << 4;
      
      // Humidity (16-bit)
      uint16_t hum = (uint16_t)(chip->humidity * 512.0f);
      data[6] = (hum >> 8) & 0xFF;
      data[7] = hum & 0xFF;
      
      // Gas resistance (16-bit)
      uint16_t gas = (uint16_t)chip->gas_res;
      data[8] = (gas >> 8) & 0xFF;
      data[9] = gas & 0xFF;
      
      return data[0]; // Simplified return
    }
    
    default:
      return 0;
  }
}

bool i2c_write(void *user_data, uint8_t data) {
  chip_state_t *chip = (chip_state_t*)user_data;
  chip->reg_addr = data;
  return true;
}

void chip_init() {
  chip_state_t *chip = malloc(sizeof(chip_state_t));
  
  // Initialize I2C device
  const i2c_config_t i2c_config = {
    .address = BME680_ADDR_PRIMARY,
    .scl = pin_init("SCL", INPUT),
    .sda = pin_init("SDA", INPUT),
    .connect = i2c_connect,
    .read = i2c_read,
    .write = i2c_write,
    .user_data = chip
  };
  chip->i2c_dev = i2c_init(&i2c_config);
  
  // Initialize attributes
  chip->temp_attr = attr_init_float("temperature", 25.0f);
  chip->hum_attr = attr_init_float("humidity", 50.0f);
  chip->press_attr = attr_init_float("pressure", 1013.25f);
  chip->gas_attr = attr_init_float("gas", 50000.0f);
  
  // Setup update timer
  const timer_config_t timer_config = {
    .callback = timer_callback,
    .user_data = chip
  };
  chip->timer = timer_init(&timer_config);
  timer_start(chip->timer, 1000000, true); // Update every 1 second
}