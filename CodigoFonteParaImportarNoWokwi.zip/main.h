/**
 * RP2040 FreeRTOS Template
 *
 * @copyright 2024, Tony Smith (@smittytone)
 * @version   1.5.0
 * @license   MIT
 *
 */
#ifndef MAIN_H
#define MAIN_H


// FreeRTOS
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "queue.h"
// C
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
// Pico SDK
#include "pico/stdlib.h"            // Includes `hardware_gpio.h`

#ifdef __cplusplus
extern "C" {
#endif

/**
 * CONSTANTS
 */
#define DIGIT1_PIN 5
#define DIGIT2_PIN 4
#define DIGIT3_PIN 3 
#define DIGIT4_PIN 2

#define A_PIN 6
#define B_PIN 7
#define C_PIN 8 
#define D_PIN 9
#define E_PIN 10
#define F_PIN 11
#define G_PIN 12

#define LED_GPIO PICO_DEFAULT_LED_PIN


#ifdef __cplusplus
}           // extern "C"
#endif


#endif      // MAIN_H